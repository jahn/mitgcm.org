package SWISHE::Doc;$VERSION=q[2.2rc1];1
