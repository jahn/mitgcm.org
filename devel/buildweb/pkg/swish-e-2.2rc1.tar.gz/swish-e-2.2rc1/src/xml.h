/*
$Id: xml.h,v 1.13 2001/10/11 22:21:14 whmoseley Exp $ 
**
**
** The prototypes
*/

int countwords_XML (SWISH *sw, FileProp *fprop, FileRec *fi, char *buffer);

