I have test this version of SWISH-E on OpenVMS 7.2-1 AXP.

Building procedure:
$ @BUILD_SWISH-E

generate SWISH-E.EXE SWISH-SEARCH.EXE TESTLIB.EXE

Testing:
$ @BUILD_SWISH-E test


Port made by Pi�ronne Jean-Fran�ois (jfp@altavista.net)
