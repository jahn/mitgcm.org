/* */


int getrank(SWISH * sw, int freq, int tfreq, int *posdata, IndexFILE *indexf, int filenum );

