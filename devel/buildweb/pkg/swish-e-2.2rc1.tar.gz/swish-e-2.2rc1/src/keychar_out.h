/*
$Id: keychar_out.h,v 1.7 2001/05/18 09:03:11 jmruiz Exp $
**
**
**
** 2001-03-20 rasc   own module for this routine  (from swish.c)
**
*/


void OutputKeyChar (SWISH *sw, int keychar);

