/*
$Id: no_better_place_module.h,v 1.1 2001/05/15 18:43:21 rasc Exp $
**
** Swish code is going to be reorganized...
**
** Better module design, better structure and better code,
** better routine names and more comments (hopefully).
**
** This module is a tmp module for code reorganization.
**
** Routines which were wrongly in other modules or are currently
** not yet assigned to a module will be tmp. moved here.
**
**
**
**
**  05/2001  rasc
 */



#ifndef __HasSeenModule_TMP_NO_BETTER_PLACE
#define __HasSeenModule_TMP_NO_BETTER_PLACE	1

/* moved prototypes here */
/* will be globally included via swish.h   */

/* $$$ to be moved to other module! */
void	translatecharHeaderOut (SWISH *sw, int v, INDEXDATAHEADER *h );




#endif


