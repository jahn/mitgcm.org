/*
$Id: txt.h,v 1.6 2001/10/11 22:21:14 whmoseley Exp $
**
**
*/

int countwords_TXT (SWISH *sw, FileProp *fprop, FileRec *fi, char *buffer);

