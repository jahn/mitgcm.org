/* 
extprog.h
*/
void initModule_Prog (SWISH  *sw);
void freeModule_Prog (SWISH *sw);
int configModule_Prog (SWISH *sw, StringList *sl);



