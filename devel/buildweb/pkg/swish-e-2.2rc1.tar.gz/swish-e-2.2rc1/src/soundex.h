/*
** soundex.h
*/


int soundex (char *word);
int soundXit (void);
